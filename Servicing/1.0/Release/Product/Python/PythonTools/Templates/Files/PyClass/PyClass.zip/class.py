class $safeitemname$:
    """description of class"""



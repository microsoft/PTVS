import wpf

from System.Windows import Window

class $safeitemname$(Window):
    def __init__(self):
        wpf.LoadComponent(self, '$safeitemname$.xaml')

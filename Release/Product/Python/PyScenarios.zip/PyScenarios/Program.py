from threading import Thread
from fg.utils import exit_flag, f, g

if __name__ == '__main__':
    ts = Thread(target=f,name="F_thread"), Thread(target=g,name="G_thread")
    for t in ts: t.start()
    k = 1
    while not exit_flag: 
        k = (k * 2) % 100000000
        

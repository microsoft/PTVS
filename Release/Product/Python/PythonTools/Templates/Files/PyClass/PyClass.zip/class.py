class $safeitemname$(object):
    """description of class"""



def subpackage_method(): pass

def subpackage_method_two(): pass
